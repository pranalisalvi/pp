package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;
import com.cg.appl.services.TraineeServices;

//http://localhost:8085/Spring120MVC_Login/login.do
@Controller
public class TraineeCrudController {
	private TraineeServices services;
	private  List<String> domainList ;
	private  List<String> locations ;
	
	@PostConstruct
	public void initialize(){
		domainList= new ArrayList<>();
		domainList.add("Java");
		domainList.add(".Net");
		domainList.add("Database");
		domainList.add("Analytics");
		
		locations= new ArrayList<>();
		locations.add("Mumbai");
		locations.add("Pune");
		locations.add("Banglore");
		locations.add("Chennai");
	}
	
	@Resource(name="traineeService")
	public void setTraineeServices(TraineeServices services){
		this.services=services;
	}
	         //Login
	@RequestMapping("/login.do")
	public ModelAndView showLoginPage(){
		ModelAndView model= new ModelAndView("login");
		return model;
	}
	@RequestMapping("/home.do")
	public ModelAndView showHomePage(){
		ModelAndView model= new ModelAndView("welcome");
		return model;
	}
	
	@RequestMapping("authenticate.do")
	public ModelAndView authenticate(@RequestParam("username") String userName,@RequestParam String password){   
		
		System.out.println(userName);
		System.out.println(password);
		ModelAndView model= new ModelAndView();
		
		if(userName.equals("a") && (password.equals("a"))){
			model.setViewName("welcome");
			model.addObject("username", userName);
		}else{
			model.addObject("message", "Login Unsuccessful.Please Reenter.");
			model.setViewName("login");
		}
		
		return model;
		
	}
	        
	         /*  //Welcome
	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage(){
		
		ModelAndView model= new ModelAndView("welcome");
		return model;
	}*/
	
	

	@RequestMapping("/enterTraineeNo.do")
	public ModelAndView enterTraineeNo(){
		System.out.println("In Controlling method");
		ModelAndView model= new ModelAndView("enterTraineeNo");
		
		
		return model;
	}
	
			//serch by no.
	@RequestMapping("/getTraineeDetails.do")
	public ModelAndView getTraineeDetails(@RequestParam("traineeNo") int traineeNo){   
		
		System.out.println("In Controlling method"+ traineeNo);
		
		ModelAndView model;
		try {
			Trainee trainee= services.getTraineeDetails(traineeNo);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails",trainee);
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		return model;
		
	}
	
			//showAll
	@RequestMapping("/listAllTrainees.do")
	public ModelAndView  listAllTrainees(){
		ModelAndView model=null;
		try {
			List<Trainee> trainees= services.getAllTrainee();
			
			model = new ModelAndView("listAllTrainees");
			model.addObject("trainees",trainees);
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		return model;
		
	}
	
			//insert
	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm(){
		
		ModelAndView model= new ModelAndView("entryForm");
	
		model.addObject("trainee", new Trainee());  //enter value of trainee that store in trainee object,so create before jsp
		model.addObject("domains", domainList);
		model.addObject("locations",locations );
		return model;
	}
	
	@RequestMapping("/submitEntryForm.do")
	public ModelAndView submitEntryForm(@ModelAttribute @Valid Trainee trainee, BindingResult result){
		
		ModelAndView model= new ModelAndView();
		
		if(result.hasErrors()){
			System.out.println(result.getAllErrors());
			model.setViewName("entryForm");
			
			model.addObject("trainee", new Trainee());  //enter value of trainee that store in trainee object,so create before jsp
			model.addObject("domains", domainList);
			model.addObject("locations",locations );
			
			return model;
		}
		try {
			Trainee traineeResponse=services.insertNewTrainee(trainee);
			
			model.setViewName("successInsert");
			model.addObject("trainee", traineeResponse);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg", "Record Insertion Failed: "+e.getMessage());
			
		}
		return model;
	}
	
	                 //update

	@RequestMapping("updateTrainee")
	public ModelAndView updateTrainee(@RequestParam("id") int traineeNo){
		
		System.out.println("In updateTrainee ID: "+traineeNo);
		ModelAndView model= null;
		try {
			Trainee trainee= services.getTraineeDetails(traineeNo);
			System.out.println("In updateTrainee "+trainee);
			
			 model= new ModelAndView("updateTraineeDetails");
				model.addObject("traineeData", trainee);
				//model.addObject("trainee", new Trainee());
				model.addObject("domains", domainList);
				model.addObject("locations", locations);
				//return model;
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", "error while getting form"+e.getMessage());
		}
		
			
		
		return model;
	}	
	
	@RequestMapping("updateTraineeData")
	public ModelAndView updateTraineeData(@ModelAttribute Trainee trainee){
		ModelAndView model= null;
		
		try {
			System.out.println(trainee);
			Trainee traineeNew= services.updateTrainee(trainee);
			System.out.println(traineeNew);
			model= new ModelAndView("updateSuccess");
			model.addObject(traineeNew);
			
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		
		
		return model;
	}
	
	//Delete
	
	@RequestMapping("deleteTrainee")
	public ModelAndView deleteTrainee(){
		ModelAndView model= new ModelAndView("deleteTraineePage");
		
		return model;
	}
	
	@RequestMapping("deleteTraineeRecord")
	public ModelAndView deleteTraineeRecord(@RequestParam("t_id") int traineeNo){
		System.out.println("Delete ID: "+traineeNo);
		ModelAndView model= null;
		try {
			//boolean flag= services.deleteTrainee(traineeNo);
			Trainee trainee= services.getTraineeDetails(traineeNo);
			model= new ModelAndView("deleteTraineePage");
			
			model.addObject("traineeData", trainee);
			
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		return model;
	}
	
	
	@RequestMapping("deleteConfirm")
	public ModelAndView deleteConfirm(@RequestParam("id") int traineeNo){
		ModelAndView model= null;
		System.out.println("In deleteConfirm: "+traineeNo);
		try {
			boolean flag= services.deleteTrainee(traineeNo);
			if(flag== true){
			model= new ModelAndView("deleteTraineePage");
			
			model.addObject("deleteMsg", "Delete Successful");
			}
		} catch (TraineeException e) {
			model= new ModelAndView("error");
			model.addObject("errMsg", e.getMessage());
		}
		return model;
	}
	
}
